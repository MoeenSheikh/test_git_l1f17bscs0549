package com.example.myapplication;

public class ListItem {
    private String name;

    public ListItem(String name)
    {
        this.name =name;
    }
    public String getName(){return  name;}

    public void setName(String n){this.name=n;}

}
