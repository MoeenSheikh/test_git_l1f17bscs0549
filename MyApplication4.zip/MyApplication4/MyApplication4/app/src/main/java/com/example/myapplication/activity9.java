package com.example.myapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class activity9 extends AppCompatActivity {

   // private RecyclerView myRecycleView;
    //private RecyclerView.Adapter adapter;
    //private List<ListItem> listItems;
    TextView mytext;
    String n;
    //Intent inte=new Intent (this,activity6.class);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity9);
        final SharedPreferences sharedpref1 = getSharedPreferences("patientinfo", Context.MODE_PRIVATE);
         mytext= findViewById(R.id.de);
        mytext.setText("");
        Bundle dataFromFirst=getIntent().getExtras();
        n=dataFromFirst.getString("message");
        if(dataFromFirst==null)
        {
            return;
        }
        displayinfo();
//recycleview
        /*myRecycleView =(RecyclerView) findViewById(R.id.recyclerView);
        myRecycleView.setHasFixedSize(true);
        myRecycleView.setLayoutManager(new LinearLayoutManager(this));

        listItems = new ArrayList<>();

        Bundle dataFromFirst=getIntent().getExtras();

        String n=dataFromFirst.getString("message");

        SharedPreferences sharedpref = getSharedPreferences("doctorinfo", Context.MODE_PRIVATE);
        int num=sharedpref.getInt("count",0);
        for (int i = 0; i < num; i++) {


            String rname = sharedpref.getString("username" + i, "");
            if (n.equals(rname)) {
                String na,e,a,h,g,t;
                long number;
                na=sharedpref.getString("username"+i ,"");
                number=sharedpref.getLong("myint"+i,0);
                e=sharedpref.getString("Email"+i,"");
                h=sharedpref.getString("Hospital"+i,"");
                a=sharedpref.getString("Address"+i,"");
                t=sharedpref.getString("Timing"+i,"");
                g=sharedpref.getString("Gender"+i,"");
                mytext.setText("Personal Information:-\nName : "+na+"\n"+"Number : "+number+"\n"+" Email : "+e+"\n"+"Hospital : "+h+"\n"+"Address : "+a+"\n"+"Timing : "+t+"\n"+"Gender :"+g+"\n");
                break;
            }*/
            //displaypatient();

        int num1=sharedpref1.getInt("count",0);
        String patntnames[]=new String[num1];
        for (int i = 0; i < num1; i++) {
            patntnames[i]=sharedpref1.getString("username"+i ,"");
        }
        ListView myListView = findViewById(R.id.mylist1);

        ArrayAdapter myArrayAdapter = new customAdapter (this, patntnames);

        myListView.setAdapter(myArrayAdapter);

        myListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //String playerName=String.valueOf(parent.getItemAtPosition(position));
                // Toast.makeText(MainActivity.this,playerName,Toast.LENGTH_LONG).show();
                String na,e,a,h,g,t;
                long number;
                na=sharedpref1.getString("username"+position ,"");
                number=sharedpref1.getLong("myint"+position,0);
                e=sharedpref1.getString("Email"+position,"");
                a=sharedpref1.getString("Address"+position,"");
                g=sharedpref1.getString("Gender"+position,"");
                showMessage("Data",na+"\n"+number+"\n"+e+"\n"+a+"\n"+g+"\n");
            }
        });

    }

    public void showMessage(String title,String Message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }
    public void displayinfo() {
        SharedPreferences sharedpref = getSharedPreferences("doctorinfo", Context.MODE_PRIVATE);
        int num = sharedpref.getInt("count", 0);
        for (int i = 0; i < num; i++) {


            String rname = sharedpref.getString("username" + i, "");
            if (n.equals(rname)) {
                String na, e, a, h, g, t;
                long number;
                na = sharedpref.getString("username" + i, "");
                number = sharedpref.getLong("myint" + i, 0);
                e = sharedpref.getString("Email" + i, "");
                h = sharedpref.getString("Hospital" + i, "");
                a = sharedpref.getString("Address" + i, "");
                t = sharedpref.getString("Timing" + i, "");
                g = sharedpref.getString("Gender" + i, "");
                mytext.setText("Personal Information:-\nName : " + na + "\n" + "Number : " + number + "\n" + " Email : " + e + "\n" + "Hospital : " + h + "\n" + "Address : " + a + "\n" + "Timing : " + t + "\n" + "Gender :" + g + "\n");
                break;
            }
        }
    }
    /*void displaypatient()
    {
        SharedPreferences sharedpref1 = getSharedPreferences("patientinfo", Context.MODE_PRIVATE);
        int num1=sharedpref1.getInt("count",0);

        for (int i = 0; i < num1; i++) {
            String us,e,a,g;
            long n;
            us=sharedpref1.getString("username"+i ,"");
            e=sharedpref1.getString("Email"+i,"");
            a=sharedpref1.getString("Address"+i,"");
            g=sharedpref1.getString("Gender"+i,"");
            n=sharedpref1.getLong("myint"+i,0);

            ListItem listitem =new ListItem("Patient " + (i+1) + "\nName: " + us + "\nEmail: " + e + "\nAddress: " + a + "\nGender: " + g + "\nPhone Number: " + n + "\n");
            listItems.add(listitem);
        }
        adapter = new myadaptor (this,listItems);
        myRecycleView.setAdapter(adapter);
    }
*/
    public void showalertbox()
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle("");
        builder.setMessage("Press logout button ");
        builder.show();
    }
    public void pl(View view)
    {
        Intent i=new Intent (this,activity6.class);
        Toast.makeText(this, "logged out", Toast.LENGTH_SHORT).show();
        startActivity(i);
        //finish();
    }
    public void he(View view)
    {
        Intent i=new Intent (this,activity14.class);
        Toast.makeText(this, "Prescribe", Toast.LENGTH_SHORT).show();
        startActivity(i);
        //finish();
    }
    @Override
    public void onBackPressed() {
        showalertbox();
        //super.onBackPressed();
        //finish();
        //Toast.makeText(this, "press logout Button", Toast.LENGTH_SHORT).show();
    }
}
