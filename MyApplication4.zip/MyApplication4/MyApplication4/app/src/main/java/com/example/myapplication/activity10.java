package com.example.myapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class activity10 extends AppCompatActivity {

    Intent inte=new Intent (this,activity6.class);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity10);
        Bundle dataFromFirst=getIntent().getExtras();
        TextView mytext= findViewById(R.id.q2);
       mytext.setText("");
        if(dataFromFirst==null)
        {
            return;
        }
        String n=dataFromFirst.getString("message");
        SharedPreferences sharedpref = getSharedPreferences("patientinfo", Context.MODE_PRIVATE);
        int num=sharedpref.getInt("count",0);
        for (int i = 0; i < num; i++) {


            String rname = sharedpref.getString("username" + i, "");
            if (n.equals(rname)) {
               String na,e,a,g;
               Long number;
               na=sharedpref.getString("username"+i ,"");
               e=sharedpref.getString("Email"+i,"");
               a=sharedpref.getString("Address"+i,"");
               g=sharedpref.getString("Gender"+i,"");
               number=sharedpref.getLong("myint"+i,0);
                mytext.setText("Name : "+na+"\n"+" Email : "+e+"\n"+"Address : "+a+"\n"+"Gender :"+g+"\n"+" Number : "+number);
               break;
            }
        }
    }


    public void logout(View view)
    {
        Intent i=new Intent (this,Activity5.class);
        Toast.makeText(this, "LOG OUT", Toast.LENGTH_SHORT).show();
        startActivity(i);
        finish();
    }
    public void showalertbox()
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle("");
        builder.setMessage("Press logout button ");
        builder.show();
    }
    @Override
    public void onBackPressed() {
        showalertbox();
        // super.onBackPressed();
    }
    public void home(View view)
    {
        Intent i=new Intent (this,MainActivity.class);
        Toast.makeText(this, "Home", Toast.LENGTH_SHORT).show();
        startActivity(i);
        finish();
    }
    public void pre(View view)
    {
        Intent i=new Intent (this,activity13.class);
        Toast.makeText(this, "Prescription", Toast.LENGTH_SHORT).show();
        startActivity(i);
        finish();
    }
    public void finghos(View view)
    {
        Intent i=new Intent (this,activity12.class);
        Toast.makeText(this, "Nearest Hospital", Toast.LENGTH_SHORT).show();
        startActivity(i);
        finish();
    }
    public void abmed(View view)
    {
        Intent i=new Intent (this,activity11.class);
        Toast.makeText(this, "About Medicine", Toast.LENGTH_SHORT).show();
        startActivity(i);
        finish();
    }
    public void condoc(View view)
    {
        Intent i=new Intent (this,activity4.class);
        Toast.makeText(this, "Contact Doctor", Toast.LENGTH_SHORT).show();
        startActivity(i);
        finish();
    }
}
