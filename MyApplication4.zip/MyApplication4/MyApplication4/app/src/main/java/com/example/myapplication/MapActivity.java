package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

public class MapActivity extends FragmentActivity implements OnMapReadyCallback {

    GoogleMap mapapi,mapapi1,mapapi2,mapapi3;
    Location currentLocation;
    FusedLocationProviderClient fusedLocationProviderClient;
    private static final int REQUEST_CODE=101;
    String n;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);
        Bundle dataFromFirst=getIntent().getExtras();
        n=dataFromFirst.getString("area");
        fusedLocationProviderClient= LocationServices.getFusedLocationProviderClient(this);
        findlastlocation();
    }

    private void findlastlocation() {
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)!= PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(this,new String[]
                    {Manifest.permission.ACCESS_FINE_LOCATION},REQUEST_CODE);
            return;
        }
        Task<Location> task=fusedLocationProviderClient.getLastLocation();
        task.addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if(location!=null)
                {
                    currentLocation=location;
                    SupportMapFragment mapfrag=(SupportMapFragment)getSupportFragmentManager().findFragmentById(R.id.mapAPI);
                    mapfrag.getMapAsync(MapActivity.this);
                }
            }
        });
    }
    @Override
    public void onMapReady(GoogleMap googleMap) {
        LatLng latLng=new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude());
        MarkerOptions options=new MarkerOptions().position(latLng).title("you are here!");
        options.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE));
        googleMap.addMarker(options);
        googleMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
        if(n.equals("JOHAR TOWN LAHORE"))
        {
            mapapi=googleMap;
            mapapi1=googleMap;
            mapapi2=googleMap;
            LatLng h1=new LatLng(31.471591, 74.275505);
            mapapi.addMarker(new MarkerOptions().position(h1).title("LIFE LINE HOSPITAL"));
            mapapi.moveCamera(CameraUpdateFactory.newLatLng(h1));

            LatLng h2=new LatLng(31.480822, 74.283073);
            mapapi1.addMarker(new MarkerOptions().position(h2).title("DOCTORS HOSPITAL"));
            mapapi1.moveCamera(CameraUpdateFactory.newLatLng(h2));

            LatLng h3=new LatLng(31.447888, 74.269507);
            mapapi2.addMarker(new MarkerOptions().position(h3).title("UNION HOSPITAL"));
            mapapi2.moveCamera(CameraUpdateFactory.newLatLng(h3));
      }
        if(n.equals("DHA LAHORE"))
        {
            mapapi=googleMap;
            mapapi1=googleMap;
            mapapi2=googleMap;
            LatLng h1=new LatLng(31.484200, 74.397324);
            mapapi.addMarker(new MarkerOptions().position(h1).title("NATIONAL HOSPITAL"));
            mapapi.moveCamera(CameraUpdateFactory.newLatLng(h1));

            LatLng h2=new LatLng(31.476939, 74.372012);
            mapapi1.addMarker(new MarkerOptions().position(h2).title("DHA MEDICAL CENTRE"));
            mapapi1.moveCamera(CameraUpdateFactory.newLatLng(h2));

            LatLng h3=new LatLng(31.489094, 74.380008);
            mapapi2.addMarker(new MarkerOptions().position(h3).title("AADIL HOSPITAL"));
            mapapi2.moveCamera(CameraUpdateFactory.newLatLng(h3));
        }
        if(n.equals("FASIAL TOWN LAHORE"))
        {
            mapapi=googleMap;
            LatLng h1=new LatLng(31.484863, 74.297220);
            mapapi.addMarker(new MarkerOptions().position(h1).title("JINNAH HOSPITAL"));
            mapapi.moveCamera(CameraUpdateFactory.newLatLng(h1));
        }
        if(n.equals("GULBERG TOWN LAHORE"))
        {
            mapapi=googleMap;
            LatLng h1=new LatLng(31.571794, 74.314244);
            mapapi.addMarker(new MarkerOptions().position(h1).title("MAYO HOSPITAL"));
            mapapi.moveCamera(CameraUpdateFactory.newLatLng(h1));
        }
        if(n.equals("SAMANABAD LAHORE"))
        {
            mapapi=googleMap;
            LatLng h1=new LatLng(31.541095, 74.332282);
            mapapi.addMarker(new MarkerOptions().position(h1).title("SERVICES HOSPITAL"));
            mapapi.moveCamera(CameraUpdateFactory.newLatLng(h1));
        }
        if(n.equals("IQBAL TOWN LAHORE"))
        {
            mapapi=googleMap;
            LatLng h1=new LatLng(31.523068, 74.289834);
            mapapi.addMarker(new MarkerOptions().position(h1).title("DOCTORS INN HOSPITAL"));
            mapapi.moveCamera(CameraUpdateFactory.newLatLng(h1));
        }
        if(n.equals("LAHORE CANTT"))
        {
            mapapi=googleMap;
            mapapi1=googleMap;

            LatLng h1=new LatLng(31.499766, 74.394770);
            mapapi.addMarker(new MarkerOptions().position(h1).title("FAUJI FOUNDATION HOSPITAL"));
            mapapi.moveCamera(CameraUpdateFactory.newLatLng(h1));

            LatLng h2=new LatLng(31.541039, 74.372762);
            mapapi1.addMarker(new MarkerOptions().position(h2).title("CMH LAHORE"));
            mapapi1.moveCamera(CameraUpdateFactory.newLatLng(h2));

        }

        if(n.equals("SHAHDARA LAHORE"))
        {
            mapapi=googleMap;
            mapapi1=googleMap;

            LatLng h1=new LatLng(31.638367, 74.285310);
            mapapi.addMarker(new MarkerOptions().position(h1).title("GOVT HOSPITAL SHAHDARA"));
            mapapi.moveCamera(CameraUpdateFactory.newLatLng(h1));

            LatLng h2=new LatLng(31.617738, 74.281963);
            mapapi1.addMarker(new MarkerOptions().position(h2).title("IBRAHIM HOSPITAL"));
            mapapi1.moveCamera(CameraUpdateFactory.newLatLng(h2));

        }

        if(n.equals("ISLAMABAD"))
        {
            mapapi=googleMap;
            mapapi1=googleMap;
            mapapi2=googleMap;
            mapapi3=googleMap;
            LatLng h1=new LatLng(33.675162, 73.066908);
            mapapi.addMarker(new MarkerOptions().position(h1).title("SHIFA INTERNATIONAL HOSPITAL"));
            mapapi.moveCamera(CameraUpdateFactory.newLatLng(h1));

            LatLng h2=new LatLng(33.708344, 73.015234);
            mapapi1.addMarker(new MarkerOptions().position(h2).title("PAF HOSPITAL"));
            mapapi1.moveCamera(CameraUpdateFactory.newLatLng(h2));

            LatLng h3=new LatLng(33.716451, 73.079740);
            mapapi2.addMarker(new MarkerOptions().position(h3).title("CDA HOSPITAL"));
            mapapi2.moveCamera(CameraUpdateFactory.newLatLng(h3));

            LatLng h4=new LatLng(33.716801, 73.084702);
            mapapi3.addMarker(new MarkerOptions().position(h4).title("ISLAMABAD MEDICAL AND SURGICAL HOSPITAL"));
            mapapi3.moveCamera(CameraUpdateFactory.newLatLng(h4));
        }
        if(n.equals("KARACHI"))
        {
            mapapi=googleMap;
            mapapi1=googleMap;
            mapapi2=googleMap;
            mapapi3=googleMap;
            LatLng h1=new LatLng(24.920089, 67.029663);
            mapapi.addMarker(new MarkerOptions().position(h1).title("ABBASI SHAHEED HOSPITAL"));
            mapapi.moveCamera(CameraUpdateFactory.newLatLng(h1));

            LatLng h2=new LatLng(24.852581, 67.042904);
            mapapi1.addMarker(new MarkerOptions().position(h2).title("JINNAH POST GRADUATE MEDICAL CENTER"));
            mapapi1.moveCamera(CameraUpdateFactory.newLatLng(h2));

            LatLng h3=new LatLng(24.892083, 67.074672);
            mapapi2.addMarker(new MarkerOptions().position(h3).title("AGHA KHAN HOSPITAL"));
            mapapi2.moveCamera(CameraUpdateFactory.newLatLng(h3));

            LatLng h4=new LatLng(24.817061, 67.111800);
            mapapi3.addMarker(new MarkerOptions().position(h4).title("THE INDUS HOSPITAL"));
            mapapi3.moveCamera(CameraUpdateFactory.newLatLng(h4));
        }

        if(n.equals("PESHAWAR"))
        {
            mapapi=googleMap;
            mapapi1=googleMap;

            LatLng h1=new LatLng(34.011013, 71.566613);
            mapapi.addMarker(new MarkerOptions().position(h1).title("READING LADY MTI HOSPITAL"));
            mapapi.moveCamera(CameraUpdateFactory.newLatLng(h1));

            LatLng h2=new LatLng(33.996206, 71.505239);
            mapapi1.addMarker(new MarkerOptions().position(h2).title("THE INDUS HOSPITAL"));
            mapapi1.moveCamera(CameraUpdateFactory.newLatLng(h2));

        }
        if(n.equals("QUETTA"))
        {
            mapapi=googleMap;
            mapapi1=googleMap;

            LatLng h1=new LatLng(30.215127, 67.031521);
            mapapi.addMarker(new MarkerOptions().position(h1).title("CMH QUETTA"));
            mapapi.moveCamera(CameraUpdateFactory.newLatLng(h1));

            LatLng h2=new LatLng(30.192324, 67.009380);
            mapapi1.addMarker(new MarkerOptions().position(h2).title("QUETTA HOSPITAL"));
            mapapi1.moveCamera(CameraUpdateFactory.newLatLng(h2));

        }

        if(n.equals("KASHMIR"))
        {
            mapapi=googleMap;
            mapapi1=googleMap;

            LatLng h1=new LatLng(33.862185, 73.760613);
            mapapi.addMarker(new MarkerOptions().position(h1).title("CMH RAWALAKOT"));
            mapapi.moveCamera(CameraUpdateFactory.newLatLng(h1));

            LatLng h2=new LatLng(34.373175, 73.465948);
            mapapi1.addMarker(new MarkerOptions().position(h2).title("SKBZ CMH MUZAFRABAD"));
            mapapi1.moveCamera(CameraUpdateFactory.newLatLng(h2));

        }

        if(n.equals("FAISALBAD"))
        {
            mapapi=googleMap;
            mapapi1=googleMap;

            LatLng h1=new LatLng(31.394839, 73.175065);
            mapapi.addMarker(new MarkerOptions().position(h1).title("SHIFA INTENATIONAL HOSPITAL"));
            mapapi.moveCamera(CameraUpdateFactory.newLatLng(h1));

            LatLng h2=new LatLng(31.449096, 73.080958);
            mapapi1.addMarker(new MarkerOptions().position(h2).title("ALLIED HOSPITAL"));
            mapapi1.moveCamera(CameraUpdateFactory.newLatLng(h2));

        }



    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode)
        {
            case REQUEST_CODE:
                if(grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED){
                    findlastlocation();
                }
                break;
        }
    }
}
